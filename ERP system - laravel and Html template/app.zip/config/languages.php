<?php

return [
    'en' => 'English',
    'he' => 'Hebrew'
];