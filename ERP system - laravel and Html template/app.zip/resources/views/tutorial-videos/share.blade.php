<div style="direction: {{ $locale == 'he' ? 'rtl' : 'ltr'}}">
    <p>{{ $messageBody }}</p>
</div>
