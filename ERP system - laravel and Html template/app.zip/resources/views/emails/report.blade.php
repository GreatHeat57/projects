<div style="direction: <?php echo ($data['locale'] == 'he' ? 'rtl' : 'ltr') ?>">
    <p>{{__('Your URL')}}: {{ $data['login_url'] }}</p>
</div>
