<div style="direction: <?php echo ($locale == 'he' ? 'rtl' : 'ltr') ?>">
    <p><?php echo $body ?></p>
</div>
