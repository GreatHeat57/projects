<div id='alert'>
    <div class='content_wrapper'>
        <p class='message'></p>
    </div>
</div>