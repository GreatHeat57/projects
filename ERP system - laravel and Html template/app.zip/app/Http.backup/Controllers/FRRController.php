<?php

namespace App\Http\Controllers;

use App\Models\FRR;
use Illuminate\Http\Request;

class FRRController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\FRR  $fRR
     * @return \Illuminate\Http\Response
     */
    public function show(FRR $fRR)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\FRR  $fRR
     * @return \Illuminate\Http\Response
     */
    public function edit(FRR $fRR)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\FRR  $fRR
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, FRR $fRR)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\FRR  $fRR
     * @return \Illuminate\Http\Response
     */
    public function destroy(FRR $fRR)
    {
        //
    }
}
