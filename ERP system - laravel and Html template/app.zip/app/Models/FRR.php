<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FRR extends Model
{
    protected $table = 'f_r_rs';
    protected $guarded = [

    ];
}
