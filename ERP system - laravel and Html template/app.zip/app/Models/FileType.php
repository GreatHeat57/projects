<?php

/**

 * Created by PhpStorm.

 * User: Nikolay

 * Date: 15.10.2018

 * Time: 6:14

 */



namespace App\Models;





use Illuminate\Database\Eloquent\Model;



class FileType extends Model

{

    protected $table = "file_types";

    protected $guarded = [];

}