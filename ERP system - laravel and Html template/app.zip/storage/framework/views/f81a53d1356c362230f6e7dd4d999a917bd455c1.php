<div style="direction: <?php echo ($data['locale'] == 'he' ? 'rtl' : 'ltr') ?>">
    <p><?php echo e(__('Your URL')); ?>: <?php echo e($data['login_url']); ?></p>
</div>
