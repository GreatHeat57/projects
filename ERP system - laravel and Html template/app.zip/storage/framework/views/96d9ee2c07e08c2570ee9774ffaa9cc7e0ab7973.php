<div style="direction: <?php echo e($locale == 'he' ? 'rtl' : 'ltr'); ?>">
    <p><?php echo e($messageBody); ?></p>
</div>
